/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.web;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import za.ac.tut.bl.StudentFacadeLocal;
import za.ac.tut.entities.Student;

/**
 *
 * @author Student
 */
@MultipartConfig
public class AddStudentServlet extends HttpServlet {
    @EJB
    private StudentFacadeLocal stl;
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            
        Integer studentNumber = Integer.parseInt(request.getParameter("student_number"));
        String name = request.getParameter("name");
        String surname = request.getParameter("surname");
        
        Part imagePart = request.getPart("image");
        
        byte[] image = convertImageToByteArray(imagePart);
        
        Student student = createStudent(studentNumber, name, surname, image);
    
        stl.create(student);
        
        Student oStud = stl.find(student.getStudentNumber());
        
        request.setAttribute("ostud", oStud);
        
        RequestDispatcher disp = request.getRequestDispatcher("add_student_outcome.jsp");
        disp.forward(request, response);
    }

    private byte[] convertImageToByteArray(Part imagePart) {
        byte[] imageByte = null;
        
        InputStream input = null;
        
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        
        byte[] buffer = new byte[1024];
        
        int byte_read = 0;
        
        try{
        
            input = imagePart.getInputStream();
            
            while( (byte_read = input.read(buffer)) != -1) {
                baos.write(buffer, 0, byte_read);
            }
            
            imageByte = baos.toByteArray();
            
        } catch(IOException ex) {
            System.out.println(ex.getMessage());
        }
        
        return imageByte;
    }

    private Student createStudent(Integer studentNumber, String name, String surname, byte[] image) {
        Student stud = new Student();
        
        stud.setStudentNumber(studentNumber);
        stud.setName(name);
        stud.setSurname(surname);
        stud.setPhoto(image);
        
        return stud;
    }
}
