/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.web;

import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.bl.StudentFacadeLocal;
import za.ac.tut.entities.Student;

/**
 *
 * @author Student
 */
public class RemoveStudentServlet extends HttpServlet {
    @EJB
    private StudentFacadeLocal stl;
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        Integer studentNumber = Integer.parseInt(request.getParameter("student_number"));
        
        Student student = stl.find(studentNumber);
        
        boolean flag = false; 
        
        if(student != null) {
            flag = true;
            
            stl.remove(student);
        }
        
        String outcome = determineOutcome(flag);
        
        request.setAttribute("studentNumber", studentNumber);
        request.setAttribute("outcome", outcome);
        
        RequestDispatcher disp = request.getRequestDispatcher("remove_outcome.jsp");
        disp.forward(request, response);
    }

    private String determineOutcome(boolean flag) {
        String outcome = "was not found in the class list, therefore removal unsuccessful";
        
        if(flag) {
            outcome = "has been removed from the class list successfully";
        }
        
        return outcome;
    }
}
